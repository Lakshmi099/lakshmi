package com.ewolff.microservice.shipping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShippingApp {

	public static void main(String[] args) {
		SpringApplication.run(ShippingApp.class, args);
	}

}
